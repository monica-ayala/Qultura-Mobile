package com.example.qulturapp.view.museum

data class TextList(
    val url:String,
    val title:String
)
