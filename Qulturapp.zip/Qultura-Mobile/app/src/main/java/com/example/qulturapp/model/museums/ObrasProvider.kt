package com.example.qulturapp.model.museums

class ObrasProvider {
    companion object{
        val obraList = listOf<Obras>(
            Obras(
                1,
                "Monalisa",
                "https://i.blogs.es/716ce3/leonardo_da_vinci_-_mona_lisa/840_560.jpg",
                "https://www.tonesmp3.com/ringtones/zara-si-dil-mein-de-jagah-kk-flute.mp3"

            ),
            Obras(
                2,
                "El Grito",
                "https://i.pinimg.com/474x/0c/57/ee/0c57ee826fe5bc4791b11aa9e857b082.jpg",
                "xd"
            ),
            Obras(
                3,
                "Las dos Fridas",
                "https://cdn.discordapp.com/attachments/1010566263828906112/1022895420332056626/unknown.png",
                "xd"
            )
        )
    }
}