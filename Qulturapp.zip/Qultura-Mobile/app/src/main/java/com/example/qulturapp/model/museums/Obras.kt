package com.example.qulturapp.model.museums

data class Obras(
    val idObras: Int,
    val nomObras: String,
    val imgObras: String,
    val audObras: String
)
