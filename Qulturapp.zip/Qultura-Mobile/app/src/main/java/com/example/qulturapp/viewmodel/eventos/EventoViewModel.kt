package com.example.qulturapp.viewmodel.eventos

class EventoViewModel {
}