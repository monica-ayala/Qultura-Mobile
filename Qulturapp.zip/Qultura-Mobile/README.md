# Qultura-Mobile
Repositorio para la parte movil de la app Qultura
