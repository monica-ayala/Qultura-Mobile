package com.example.qulturapp

class Constants {
}