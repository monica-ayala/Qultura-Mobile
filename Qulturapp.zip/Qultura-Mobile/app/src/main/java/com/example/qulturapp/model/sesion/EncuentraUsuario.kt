package com.example.qulturapp.model.sesion

import com.google.gson.annotations.SerializedName

data class EncuentraUsuario(
    @SerializedName("paso") val paso: Int
)
